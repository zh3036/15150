import loop2.pm
in
   structure A.sig
end
