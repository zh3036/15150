#ifndef _mosml_
#define _mosml_

#include "mlvalues.h"

char* exnmessage_aux(value);

#endif /* _mosml_ */
