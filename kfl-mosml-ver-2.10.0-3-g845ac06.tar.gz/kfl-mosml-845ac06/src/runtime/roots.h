#ifndef _roots_
#define _roots_

#include "misc.h"

void local_roots (void (*copy_fn) (value *, value));


#endif /* _roots_ */
