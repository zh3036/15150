#define VERSION "0.8e for Moscow ML"
