#define HAS_MEMMOVE
#define HAS_BCOPY
#define HAS__SETJMP
#define sighandler_return_type void
/* #define BSD_SIGNALS */
#define HAS_RENAME
#define HAS_STRERROR
#define HAS_SOCKETS
#define HAS_UNISTD
#define HAS_DIRENT
#define HAS_LOCKF
#define HAS_MKFIFO
#define HAS_GETPRIORITY
#define HAS_UTIME
#define HAS_UTIMES
#define HAS_DUP2
#define HAS_FCHMOD
#define HAS_TRUNCATE
#define HAS_SELECT
/* #define HAS_SYMLINK */
/* #define HAS_WAIT3 */
/* #define HAS_WAITPID */
/* #define HAS_TERMIOS */
